package com.example.login;

import java.util.LinkedList;

public class Repositorio {
    LinkedList<Usuario> usuarios = new LinkedList<Usuario>();
}
